import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FrameAndLayout
{

	private static JFrame jf;
	private static JPanel centerPanel,northJPanel;
	private static JTextArea showFile,preview;
	private static JTextField pathField = null;
	private static JButton show,fileChoose,rename;
	private static String[] fileNames,previewFileName;
	public static void main(String[] args) 
	{
		//initial a Frame , set size 1024x768 ,close button will close window
		jf = new JFrame();
		jf.setSize(1500,768);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//create a panel will put at center ,inside has two TextArea
		centerPanel = new JPanel();
		GridLayout gLayout = new GridLayout(1,2);
		gLayout.setVgap(10);
		centerPanel.setLayout(gLayout);
		jf.getContentPane().add(BorderLayout.CENTER,centerPanel);
		
		//show files and directories 
		showFile = new JTextArea(); 
		centerPanel.add(showFile);
		
		//show rename preview
		preview = new JTextArea();
		preview.setBackground(Color.YELLOW);
		centerPanel.add(preview);
		
		//create a panel put at north , inside has a Text Field and three button
		northJPanel = new JPanel();
		northJPanel.setLayout(new FlowLayout());
		jf.getContentPane().add(BorderLayout.NORTH,northJPanel);
		
		//a text field can enter a path
		pathField = new JTextField(50);
		pathField.setSize(700,50);
		northJPanel.add(pathField);
		
		//check path and show information at "showFile"
		show = new JButton("show");
		show.addActionListener(new ActionListener() 
		{	@Override
			public void actionPerformed(ActionEvent e) 
			{	// TODO Auto-generated method stub
				checkPathAndShowInfo(); } } );
		northJPanel.add(show);
		
		//call FileChooser let user select directories
		fileChoose =new JButton("Select");
		northJPanel.add(fileChoose);
		
		//if path is correct ,rename the file and  directories
		rename = new JButton("Rename");
		northJPanel.add(rename);
		
		jf.setVisible(true);
		
		String str="[脸肿汉化组](C85) [サイクロン (冷泉, 和泉)] Cho!! 3 Tai Choooo (魔法少女リリカルなのは)"+"\n"+"[不做艦娘漢化組](C85) [自称清純派 (ヒロユキ) ] もっと速くなりたい島風をダマしてセクハラする (艦隊これくしょん -艦これ-)";
		showFile.setText(str);
		preview.setText(str);
		
		
	}

	protected static void checkPathAndShowInfo() 
	{
		// TODO Auto-generated method stub
		if(pathField==null)
		{
			JOptionPane.showMessageDialog(null,  "Initial faile" ,"Error" , JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		String path = pathField.getText();
		File dir = new File(path);
		if((!dir.exists())||(!dir.isDirectory()))
		{
			JOptionPane.showMessageDialog(null,"Directory doesn't exist or this path isn't a directory", "Error" , JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		fileNames=dir.list();
		showStringArray(fileNames, showFile);
		showPreview();
	}
	
	protected static void showPreview()
	{
		previewFileName = fileNames.clone();
		for(int i=0;i<previewFileName.length;i++)
		{
			previewFileName[i] = analysisAndRename(previewFileName[i]);
		}
		showStringArray(previewFileName, preview);
	}
	
	private static String analysisAndRename(String name) 
	{
		// TODO Auto-generated method stub
		ArrayList<String> sList = new ArrayList<String>();
		boolean splitDone = false;
		while(!splitDone)
		{
			switch (name.charAt(0)) 
			{
			case '(':
				sList.add(name.substring(0, name.indexOf(')')));
				name = name.substring(name.indexOf(')')+1);
				break;
			case '[':
				break;
			case '【':
				break;
			case ' ':
				break;
			default:
				splitDone=true;
				break;
			}
		}
		return null;
	}

	private static void showStringArray(String[] strArray,JTextArea ta)
	{
		StringBuffer strToShow = new StringBuffer();
		for(String str : strArray)
		{
			strToShow.append(str);
			strToShow.append('\n');
		}
		ta.setText(strToShow.toString());
	}
}
//[脸肿汉化组](C85) [サイクロン (冷泉, 和泉)] Cho!! 3 Tai Choooo (魔法少女リリカルなのは)
//[不做艦娘漢化組](C85) [自称清純派 (ヒロユキ) ] もっと速くなりたい島風をダマしてセクハラする (艦隊これくしょん -艦これ- )